/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{jsx,ts,tsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
