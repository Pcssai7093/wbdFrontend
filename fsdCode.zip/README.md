command to start the app (only a single command to run both frontend and backend)

npm start

Note: make sure you are in the project folder

Node modules are not in the zip, plese use commands
npm i
in the root folder and
npm i
in the server folder (folder with server name)
