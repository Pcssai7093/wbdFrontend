// module.exports = {
//   // ...
//   resolve: {
//     fallback: {
//       util: require.resolve("util/"),
//       assert: require.resolve("assert/"),
//       child_process: "empty",
//       fs: "empty",
//     },
//   },
//   // ...
// };
