import styles from "./Space.module.css";
function Space() {
  return <div className={styles.Space}></div>;
}

export default Space;
