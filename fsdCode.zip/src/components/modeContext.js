import React, { createContext } from "react";
const modeContext = createContext();
export default modeContext;